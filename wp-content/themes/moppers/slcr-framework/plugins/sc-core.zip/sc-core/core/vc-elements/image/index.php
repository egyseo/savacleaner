<?php
/**
 *  slcr WordPress Theme 
 * 
 **/
 ?>