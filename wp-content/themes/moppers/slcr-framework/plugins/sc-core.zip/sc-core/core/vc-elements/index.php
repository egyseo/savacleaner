<?php
/**
 *  slcr WordPress Theme 
 *
 * @author     SlashCreative
 * @copyright  (c) Copyright by SlashCreative
 * @link       http://slashcreative.co
 * @package    SC-CORE
 * @subpackage Core
 * @since      1.0.0
 * silence is golden, prevent direct access!
 **/  